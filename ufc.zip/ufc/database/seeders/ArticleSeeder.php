<?php

namespace Database\Seeders;

use App\Models\Article;
use Illuminate\Database\Seeder;

class ArticleSeeder extends Seeder
{
    public function run(): void
    {
        $articles = [
            [
                'title' => 'Большой футбольный сезон впереди',
                'slug' => 'bolshoy-futbolnyy-sezon',
                'excerpt' => 'Команды готовятся к новым матчам, а болельщики ждут ярких противостояний.',
                'content' => 'Новый футбольный сезон обещает множество интересных матчей. Клубы работают над составами, тренеры выбирают тактику, а болельщики готовятся поддерживать любимые команды.',
                'category' => 'Европа',
                'author' => 'Редакция',
                'is_published' => true,
            ],
            [
                'title' => 'Трансферные новости: начинается борьба за игроков',
                'slug' => 'transfernye-novosti',
                'excerpt' => 'Клубы продолжают искать усиление перед важными матчами.',
                'content' => 'Трансферный рынок остаётся важной частью футбола. Руководители клубов оценивают возможности, а тренеры ищут игроков, способных усилить команду.',
                'category' => 'Трансферы',
                'author' => 'Спортивный обозреватель',
                'is_published' => true,
            ],
            [
                'title' => 'Российский футбол готовится к новым испытаниям',
                'slug' => 'rossiyskiy-futbol',
                'excerpt' => 'Команды РПЛ продолжают борьбу за высокие места в турнирной таблице.',
                'content' => 'В российском футболе каждый тур может повлиять на положение команд. Результаты матчей, работа тренеров и форма игроков определяют ход чемпионата.',
                'category' => 'РПЛ',
                'author' => 'Редакция',
                'is_published' => true,
            ],
        ];

        foreach ($articles as $article) {
            Article::updateOrCreate(
                ['slug' => $article['slug']],
                $article
            );
        }
    }
}

<?php

namespace Database\Seeders;

use App\Models\Article;
use Illuminate\Database\Seeder;

class UfcDemoSeeder extends Seeder
{
    public function run(): void
    {
        $materials = [
            ['demo-ufc-fights', 'Перед поединком: на что обратить внимание', 'Поединки', 'Стили бойцов, подготовка и ожидания перед выходом в октагон.', 'У каждого поединка есть своя история. В этом разделе можно публиковать анонсы боёв, рассказывать о подготовке соперников и обсуждать ожидания зрителей.'],
            ['demo-ufc-fighters', 'Бойцы и их путь в октагон', 'Бойцы', 'Истории спортсменов, тренировки и работа над собой.', 'За выходом в октагон стоит долгая подготовка. Здесь можно рассказывать о бойцах, их тренировках, командах и личных целях.'],
            ['demo-ufc-events', 'UFC: новости и события', 'UFC', 'Место для анонсов турниров и новостей организации.', 'Следите за новыми публикациями редакции. В этом разделе можно размещать анонсы турниров, интервью и обзоры событий мира UFC.'],
        ];

        foreach ($materials as [$slug, $title, $category, $excerpt, $content]) {
            Article::firstOrCreate(['slug' => $slug], compact('title', 'category', 'excerpt', 'content') + ['author' => 'Редакция', 'is_published' => true]);
        }
    }
}

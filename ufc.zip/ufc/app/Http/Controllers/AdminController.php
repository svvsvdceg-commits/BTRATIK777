<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AdminController extends Controller
{
    public function index()
    {
        $articles = Article::latest()->get();

        return view('admin.index', compact('articles'));
    }

    public function edit(Article $article)
    {
        return view('admin.edit', compact('article'));
    }

    public function update(Request $request, Article $article)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'image' => 'nullable|url|max:255',
            'excerpt' => 'nullable|string',
            'content' => 'required|string',
        ]);

        $article->update([
            'title' => $validated['title'],
            'slug' => Str::slug($validated['title']) . '-' . $article->id,
            'category' => $validated['category'],
            'image' => $validated['image'] ?? null,
            'excerpt' => $validated['excerpt'] ?? null,
            'content' => $validated['content'],
        ]);

        return redirect()
            ->route('admin.index')
            ->with('success', 'Новость успешно обновлена.');
    }

    public function togglePublication(Article $article)
    {
        $article->is_published = !$article->is_published;
        $article->save();

        return redirect()
            ->route('admin.index')
            ->with('success', 'Статус публикации изменён.');
    }

    public function destroy(Article $article)
    {
        $article->delete();

        return redirect()
            ->route('admin.index')
            ->with('success', 'Новость удалена.');
    }
}

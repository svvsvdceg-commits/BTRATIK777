<?php $__env->startSection('title', 'Пользователи — Октагон'); ?>
<?php $__env->startSection('content'); ?>
    <div class="article-page">
        <a href="<?php echo e(route('admin.index')); ?>">← Назад в админку</a>
        <h1>Управление пользователями</h1>
        <?php echo $__env->make('partials.notices', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="manage-item">
                <h3><?php echo e($user->name); ?></h3>
                <p class="muted"><?php echo e($user->email); ?></p>
                <form class="role-form" action="<?php echo e(route('admin.users.role', $user)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <select name="role" aria-label="Роль пользователя <?php echo e($user->name); ?>" required>
                        <?php $__currentLoopData = ['user' => 'Пользователь', 'journalist' => 'Журналист', 'admin' => 'Администратор']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role); ?>" <?php if(($user->role ?? 'user') === $role): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button type="submit">Сохранить роль</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="page-intro">Пользователей пока нет.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\krasn\OneDrive\Desktop\football-news-new\resources\views/admin/users.blade.php ENDPATH**/ ?>
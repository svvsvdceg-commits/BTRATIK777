<header class="topbar">
    <div class="container header">
        <a href="<?php echo e(route('home')); ?>" class="logo">ОКТА<span>ГОН</span><small>Новости UFC и MMA</small></a>
        <nav aria-label="Основное меню">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home')]); ?>">Главная</a>
            <?php $__currentLoopData = \App\Models\Article::CATEGORIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('category', $section)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->route('category') === $section]); ?>"><?php echo e($section); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('journalist.create')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['staff-link', 'active' => request()->routeIs('journalist.*')]); ?>">Журналист</a>
            <a href="<?php echo e(route('admin.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['staff-link', 'active' => request()->routeIs('admin.*')]); ?>">Админ</a>
        </nav>
    </div>
</header>
<?php /**PATH C:\Users\krasn\OneDrive\Desktop\football-news-new\resources\views/partials/header.blade.php ENDPATH**/ ?>
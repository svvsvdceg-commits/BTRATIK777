<div class="field">
    <label for="title">Заголовок новости</label>
    <input id="title" name="title" type="text" value="<?php echo e(old('title', $article?->title)); ?>" required maxlength="255">
</div>
<div class="field">
    <label for="category">Категория</label>
    <select id="category" name="category" required>
        <option value="">Выберите категорию</option>
        <?php ($selectedCategory = old('category', $article?->category)); ?>
        <?php if($selectedCategory && !in_array($selectedCategory, \App\Models\Article::CATEGORIES, true)): ?>
            <option value="<?php echo e($selectedCategory); ?>" selected><?php echo e($selectedCategory); ?> (прежняя категория)</option>
        <?php endif; ?>
        <?php $__currentLoopData = \App\Models\Article::CATEGORIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category); ?>" <?php if($selectedCategory === $category): echo 'selected'; endif; ?>><?php echo e($category); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="field">
    <label for="image">Ссылка на изображение (необязательно)</label>
    <input id="image" name="image" type="url" value="<?php echo e(old('image', $article?->image)); ?>" maxlength="255" placeholder="https://…">
</div>
<div class="field">
    <label for="excerpt">Краткое описание</label>
    <textarea id="excerpt" name="excerpt" rows="3"><?php echo e(old('excerpt', $article?->excerpt)); ?></textarea>
</div>
<div class="field">
    <label for="content">Полный текст новости</label>
    <textarea id="content" name="content" rows="8" required><?php echo e(old('content', $article?->content)); ?></textarea>
</div>
<?php /**PATH C:\Users\krasn\OneDrive\Desktop\football-news-new\resources\views/partials/article-fields.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Редактирование новости — Октагон'); ?>
<?php $__env->startSection('content'); ?>
    <div class="article-page">
        <a href="<?php echo e(route('admin.index')); ?>">← Назад в админку</a>
        <h1>Редактировать новость</h1>
        <?php echo $__env->make('partials.notices', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form action="<?php echo e(route('admin.articles.update', $article)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('partials.article-fields', ['article' => $article], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <button type="submit">Сохранить изменения</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\krasn\OneDrive\Desktop\football-news-new\resources\views/admin/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $article->title . ' — Октагон'); ?>
<?php $__env->startSection('content'); ?>
    <article class="article-page">
        <a href="<?php echo e(route('home')); ?>">← Назад к новостям</a>
        <div class="article-category"><a class="category-tag" href="<?php echo e(route('category', $article->category)); ?>"><?php echo e($article->category); ?></a></div>
        <h1><?php echo e($article->title); ?></h1>
        <p class="muted">Автор: <?php echo e($article->author); ?> · <?php echo e($article->created_at->format('d.m.Y H:i')); ?></p>
        <?php if($article->image): ?>
            <img class="article-image" src="<?php echo e($article->image); ?>" alt="<?php echo e($article->title); ?>">
        <?php endif; ?>
        <?php if($article->excerpt): ?>
            <p class="article-intro"><?php echo e($article->excerpt); ?></p>
        <?php endif; ?>
        <div class="article-text"><?php echo e($article->content); ?></div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\krasn\OneDrive\Desktop\football-news-new\resources\views/articles/show.blade.php ENDPATH**/ ?>
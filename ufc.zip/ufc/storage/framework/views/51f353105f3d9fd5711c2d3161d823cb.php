<?php $__env->startSection('title', ($category ?? 'Главная') . ' — Октагон'); ?>
<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-copy">
            <div class="hero-label">UFC · Смешанные единоборства</div>
            <h1>Всё, что происходит в октагоне.</h1>
            <p>Новости поединков, истории бойцов и события мира MMA. Выберите раздел или найдите нужную статью.</p>
        </div>
        <img class="hero-image" src="<?php echo e(asset('images/ufc-champions.jpg')); ?>" alt="Бойцы UFC с чемпионскими поясами">
    </section>
    <?php ($listingUrl = isset($category) ? route('category', $category) : route('home')); ?>
    <form action="<?php echo e($listingUrl); ?>" method="GET" class="search-form" role="search">
        <input type="search" name="search" aria-label="Поиск новостей по заголовку" placeholder="Найти новость по заголовку…" value="<?php echo e($search); ?>">
        <button type="submit">Найти</button>
        <?php if($search !== ''): ?>
            <a href="<?php echo e($listingUrl); ?>">Сбросить</a>
        <?php endif; ?>
    </form>
    <div class="section-heading">
        <h2><?php echo e($category ?? 'Последние новости'); ?></h2>
        <span class="muted"><?php echo e($search !== '' ? 'Найдено' : 'Материалов'); ?>: <?php echo e($articles->count()); ?></span>
    </div>
    <div class="news-grid">
        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a class="news-card" href="<?php echo e(route('article.show', $article->slug)); ?>">
                <img class="news-image" loading="lazy" src="<?php echo e($article->image ?: asset('images/' . ($article->category === 'Бойцы' ? 'ufc-fighter.jpg' : 'ufc-fight.jpg'))); ?>" alt="<?php echo e($article->title); ?>">
                <div class="news-content">
                    <span class="category-tag"><?php echo e($article->category); ?></span>
                    <h3><?php echo e($article->title); ?></h3>
                    <p><?php echo e($article->excerpt ?: \Illuminate\Support\Str::limit($article->content, 120)); ?></p>
                    <div class="news-meta"><?php echo e($article->author); ?> · <?php echo e($article->created_at->format('d.m.Y')); ?></div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty">
                <h3><?php echo e($search !== '' ? 'Ничего не найдено' : 'Пока нет новостей'); ?></h3>
                <p><?php echo e($search !== '' ? 'Попробуйте другое слово или сбросьте поиск.' : 'Новые материалы появятся здесь после публикации.'); ?></p>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\krasn\OneDrive\Desktop\football-news-new\resources\views/articles/index.blade.php ENDPATH**/ ?>
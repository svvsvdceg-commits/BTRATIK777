<?php $__env->startSection('title', 'Админка — Октагон'); ?>
<?php $__env->startSection('content'); ?>
    <div class="article-page">
        <h1>Управление новостями</h1>
        <a href="<?php echo e(route('admin.users')); ?>">Управление пользователями</a>
        <?php echo $__env->make('partials.notices', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="manage-item">
                <h3><?php echo e($article->title); ?></h3>
                <a class="edit-link" href="<?php echo e(route('admin.articles.edit', $article)); ?>">Редактировать</a>
                <p class="muted">Категория: <?php echo e($article->category); ?> · Статус: <?php echo e($article->is_published ? 'Опубликована' : 'Заблокирована'); ?></p>
                <div class="actions">
                    <form action="<?php echo e(route('admin.articles.toggle', $article)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button class="button-secondary" type="submit"><?php echo e($article->is_published ? 'Заблокировать' : 'Опубликовать'); ?></button>
                    </form>
                    <form action="<?php echo e(route('admin.articles.destroy', $article)); ?>" method="POST" onsubmit="return confirm('Точно удалить эту новость?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="button-danger" type="submit">Удалить</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="manage-item"><p>Новостей пока нет.</p></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\krasn\OneDrive\Desktop\football-news-new\resources\views/admin/index.blade.php ENDPATH**/ ?>
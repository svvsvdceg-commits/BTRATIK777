<?php $__env->startSection('title', 'Журналист — Октагон'); ?>
<?php $__env->startSection('content'); ?>
    <div class="article-page">
        <h1>Добавить новость</h1>
        <p class="page-intro">Напишите о поединке, бойце или событии UFC.</p>
        <?php echo $__env->make('partials.notices', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form action="<?php echo e(route('journalist.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('partials.article-fields', ['article' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <button type="submit">Опубликовать новость</button>
        </form>
    </div>
    <section class="added-news">
        <h2>Добавленные новости</h2>
        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="manage-item">
                <h3><?php echo e($article->title); ?></h3>
                <p class="muted"><?php echo e($article->category); ?> · <?php echo e($article->created_at->format('d.m.Y')); ?> · <?php echo e($article->is_published ? 'Опубликована' : 'Заблокирована'); ?></p>
                <div class="actions">
                    <?php if($article->is_published): ?>
                        <a href="<?php echo e(route('article.show', $article->slug)); ?>">Открыть новость</a>
                    <?php else: ?>
                        <span class="muted">Публикация скрыта</span>
                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.articles.edit', $article)); ?>">Редактировать</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty"><p>Пока нет добавленных новостей.</p></div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\krasn\OneDrive\Desktop\football-news-new\resources\views/journalist/create.blade.php ENDPATH**/ ?>
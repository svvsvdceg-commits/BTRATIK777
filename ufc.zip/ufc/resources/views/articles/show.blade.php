@extends('layouts.app')
@section('title', $article->title . ' — Октагон')
@section('content')
    <article class="article-page">
        <a href="{{ route('home') }}">← Назад к новостям</a>
        <div class="article-category"><a class="category-tag" href="{{ route('category', $article->category) }}">{{ $article->category }}</a></div>
        <h1>{{ $article->title }}</h1>
        <p class="muted">Автор: {{ $article->author }} · {{ $article->created_at->format('d.m.Y H:i') }}</p>
        @if ($article->image)
            <img class="article-image" src="{{ $article->image }}" alt="{{ $article->title }}">
        @endif
        @if ($article->excerpt)
            <p class="article-intro">{{ $article->excerpt }}</p>
        @endif
        <div class="article-text">{{ $article->content }}</div>
    </article>
@endsection

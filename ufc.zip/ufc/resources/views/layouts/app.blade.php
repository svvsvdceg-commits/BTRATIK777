<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Октагон — новости UFC')</title>
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body>
    @include('partials.header')
    <main class="container" id="content">
        @yield('content')
    </main>
    @include('partials.footer')
</body>
</html>

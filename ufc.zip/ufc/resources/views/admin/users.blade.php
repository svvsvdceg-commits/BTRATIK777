@extends('layouts.app')
@section('title', 'Пользователи — Октагон')
@section('content')
    <div class="article-page">
        <a href="{{ route('admin.index') }}">← Назад в админку</a>
        <h1>Управление пользователями</h1>
        @include('partials.notices')
        @forelse ($users as $user)
            <div class="manage-item">
                <h3>{{ $user->name }}</h3>
                <p class="muted">{{ $user->email }}</p>
                <form class="role-form" action="{{ route('admin.users.role', $user) }}" method="POST">
                    @csrf
                    @method('PATCH')
                    <select name="role" aria-label="Роль пользователя {{ $user->name }}" required>
                        @foreach (['user' => 'Пользователь', 'journalist' => 'Журналист', 'admin' => 'Администратор'] as $role => $label)
                            <option value="{{ $role }}" @selected(($user->role ?? 'user') === $role)>{{ $label }}</option>
                        @endforeach
                    </select>
                    <button type="submit">Сохранить роль</button>
                </form>
            </div>
        @empty
            <p class="page-intro">Пользователей пока нет.</p>
        @endforelse
    </div>
@endsection

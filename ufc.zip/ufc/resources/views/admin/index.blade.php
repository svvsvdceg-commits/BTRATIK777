@extends('layouts.app')
@section('title', 'Админка — Октагон')
@section('content')
    <div class="article-page">
        <h1>Управление новостями</h1>
        <a href="{{ route('admin.users') }}">Управление пользователями</a>
        @include('partials.notices')
        @forelse ($articles as $article)
            <div class="manage-item">
                <h3>{{ $article->title }}</h3>
                <a class="edit-link" href="{{ route('admin.articles.edit', $article) }}">Редактировать</a>
                <p class="muted">Категория: {{ $article->category }} · Статус: {{ $article->is_published ? 'Опубликована' : 'Заблокирована' }}</p>
                <div class="actions">
                    <form action="{{ route('admin.articles.toggle', $article) }}" method="POST">
                        @csrf
                        @method('PATCH')
                        <button class="button-secondary" type="submit">{{ $article->is_published ? 'Заблокировать' : 'Опубликовать' }}</button>
                    </form>
                    <form action="{{ route('admin.articles.destroy', $article) }}" method="POST" onsubmit="return confirm('Точно удалить эту новость?')">
                        @csrf
                        @method('DELETE')
                        <button class="button-danger" type="submit">Удалить</button>
                    </form>
                </div>
            </div>
        @empty
            <div class="manage-item"><p>Новостей пока нет.</p></div>
        @endforelse
    </div>
@endsection

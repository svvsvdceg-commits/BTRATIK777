<div class="field">
    <label for="title">Заголовок новости</label>
    <input id="title" name="title" type="text" value="{{ old('title', $article?->title) }}" required maxlength="255">
</div>
<div class="field">
    <label for="category">Категория</label>
    <select id="category" name="category" required>
        <option value="">Выберите категорию</option>
        @php($selectedCategory = old('category', $article?->category))
        @if ($selectedCategory && !in_array($selectedCategory, \App\Models\Article::CATEGORIES, true))
            <option value="{{ $selectedCategory }}" selected>{{ $selectedCategory }} (прежняя категория)</option>
        @endif
        @foreach (\App\Models\Article::CATEGORIES as $category)
            <option value="{{ $category }}" @selected($selectedCategory === $category)>{{ $category }}</option>
        @endforeach
    </select>
</div>
<div class="field">
    <label for="image">Ссылка на изображение (необязательно)</label>
    <input id="image" name="image" type="url" value="{{ old('image', $article?->image) }}" maxlength="255" placeholder="https://…">
</div>
<div class="field">
    <label for="excerpt">Краткое описание</label>
    <textarea id="excerpt" name="excerpt" rows="3">{{ old('excerpt', $article?->excerpt) }}</textarea>
</div>
<div class="field">
    <label for="content">Полный текст новости</label>
    <textarea id="content" name="content" rows="8" required>{{ old('content', $article?->content) }}</textarea>
</div>

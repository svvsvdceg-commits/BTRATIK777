<header class="topbar">
    <div class="container header">
        <a href="{{ route('home') }}" class="logo">ОКТА<span>ГОН</span><small>Новости UFC и MMA</small></a>
        <nav aria-label="Основное меню">
            <a href="{{ route('home') }}" @class(['active' => request()->routeIs('home')])>Главная</a>
            @foreach (\App\Models\Article::CATEGORIES as $section)
                <a href="{{ route('category', $section) }}" @class(['active' => request()->route('category') === $section])>{{ $section }}</a>
            @endforeach
            <a href="{{ route('journalist.create') }}" @class(['staff-link', 'active' => request()->routeIs('journalist.*')])>Журналист</a>
            <a href="{{ route('admin.index') }}" @class(['staff-link', 'active' => request()->routeIs('admin.*')])>Админ</a>
        </nav>
    </div>
</header>

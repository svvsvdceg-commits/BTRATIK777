<?php

namespace Tests\Feature;

use App\Models\Article;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UfcSiteTest extends TestCase
{
    use RefreshDatabase;

    private function article(array $attributes = []): Article
    {
        return Article::create($attributes + [
            'title' => 'Анонс поединка', 'slug' => 'fight-'.uniqid(),
            'category' => 'Поединки', 'content' => 'Материал о подготовке.',
            'author' => 'Редакция', 'is_published' => true,
        ]);
    }

    public function test_home_and_category_search_only_show_matching_published_articles(): void
    {
        $this->article(['title' => 'Обзор UFC 0']);
        $this->article(['title' => 'Другой обзор']);
        $this->article(['title' => 'Бойцы UFC 0', 'category' => 'Бойцы']);
        $hidden = $this->article(['title' => 'Скрытая новость UFC 0', 'is_published' => false]);

        $this->get(route('home'))->assertOk()->assertSee('ОКТА')->assertDontSee($hidden->title);
        $this->get(route('category', 'Поединки').'?search=0')
            ->assertOk()->assertSee('Обзор UFC 0')->assertDontSee('Другой обзор')->assertDontSee('Бойцы UFC 0');
        $this->get(route('home').'?search=несуществующий')->assertOk()->assertSee('Ничего не найдено');
        $this->get(route('article.show', $hidden->slug))->assertNotFound();
        $this->get(route('home').'?search[]=invalid')->assertRedirect()->assertSessionHasErrors('search');
    }

    public function test_journalist_can_create_and_admin_can_edit_toggle_and_delete(): void
    {
        $this->get(route('journalist.create'))->assertOk()->assertSee('Опубликовать новость');
        $this->post(route('journalist.store'), [
            'title' => 'Новый материал UFC', 'category' => 'UFC', 'content' => 'Текст статьи.',
        ])->assertRedirect(route('journalist.create'));
        $article = Article::firstOrFail();
        $this->get(route('article.show', $article->slug))->assertOk()->assertSee('Текст статьи.');
        $this->get(route('admin.index'))->assertOk()->assertSee('Редактировать')->assertSee('Удалить');
        $this->get(route('admin.articles.edit', $article))->assertOk()->assertSee('Сохранить изменения');
        $this->put(route('admin.articles.update', $article), [
            'title' => 'Обновлённый материал', 'category' => 'Бойцы', 'content' => 'Новый текст.',
        ])->assertRedirect(route('admin.index'));
        $this->assertDatabaseHas('articles', ['id' => $article->id, 'title' => 'Обновлённый материал', 'category' => 'Бойцы']);
        $this->patch(route('admin.articles.toggle', $article))->assertRedirect(route('admin.index'));
        $this->get(route('home'))->assertDontSee('Обновлённый материал');
        $this->get(route('journalist.create'))->assertOk()->assertSee('Публикация скрыта');
        $this->get(route('article.show', $article->fresh()->slug))->assertNotFound();
        $this->patch(route('admin.articles.toggle', $article));
        $this->get(route('article.show', $article->fresh()->slug))->assertOk();
        $this->delete(route('admin.articles.destroy', $article))->assertRedirect(route('admin.index'));
        $this->assertDatabaseMissing('articles', ['id' => $article->id]);
    }

    public function test_roles_can_be_changed_and_invalid_roles_are_rejected(): void
    {
        $user = User::factory()->create();
        $this->get(route('admin.users'))->assertOk()->assertSee($user->name)->assertSee('Сохранить роль');
        $this->patch(route('admin.users.role', $user), ['role' => 'journalist'])->assertRedirect(route('admin.users'));
        $this->assertDatabaseHas('users', ['id' => $user->id, 'role' => 'journalist']);
        $this->patch(route('admin.users.role', $user), ['role' => 'invalid'])->assertSessionHasErrors('role');
    }

    public function test_existing_article_category_and_form_validation_are_preserved(): void
    {
        $article = $this->article(['category' => 'РПЛ']);
        $this->get(route('admin.articles.edit', $article))->assertOk()->assertSee('РПЛ (прежняя категория)');
        $this->post(route('journalist.store'), [])->assertSessionHasErrors(['title', 'category', 'content']);
    }
}
